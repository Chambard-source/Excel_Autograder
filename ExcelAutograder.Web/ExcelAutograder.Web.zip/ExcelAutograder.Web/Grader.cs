﻿public static partial  class Grader
{

}